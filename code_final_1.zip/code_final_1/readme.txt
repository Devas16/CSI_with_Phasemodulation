This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Q. Yu and L. Dai, "Near-field wideband beamforming for RIS based on Fresnel zone," IEEE Trans. Commun., 2024.


*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 

The author in charge of this simulation code pacakge is: Qiumo Yu (email: yqm22@mails.tsinghua.edu.cn, yuqiumo2012@126.com).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that the MATLAB R2021a is used for this simulation code package,  and there may be some imcompatibility problems among different software versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Tsinghua National Laboratory
for Information Science and Technology (TNList), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 


*********************************************************************************************************************************
How to use this simulation code package?

1. Run "Fig_Beamforming_Performance.m" to obtain the results in Fig. 7.

2. Run "Fig_sum_rate_vs_power.m" to obtain the results in Fig. 8.

3. Run "Fig_sum_rate_vs_sidelength.m" to obtain the results in Fig. 9.

4. Run "Fig_sum_rate_vs_bandwidth.m" to obtain the results in Fig. 10.

5. Run "Fig_sum_rate_vs_dist.m" to obtain the results in Fig. 11.

6. Run "Fig_sum_rate_vs_nBS.m" to obtain the results in Fig. 12.

7. The functions worth further explanations:
    "my_compute_rate.m" is used to compute the achievable rate for the proposed Fresnel zone-based beamforming and the upper and lower bound. 
    "Beamforming.m" is the funciton for proposed Fresnel zone-based beamforming.
    "TRXpos_gen.m" generates the location of TX and RX randomly, with outputs stored in "TRX_std.mat", "TRX_same_dist".	

8. Variable "NTRX" indicates the number of random tests with different BS and UE location, which should not exceed 10000. You may reduce the value of "NTRX" to decrease the simulation time. 

9. The running results are stored in folder "./data". Variable "cal_rate" controls whether the code is re-executed. 

10. Part of the code are referenced from the code of [2]

[2]  N. J. Myers and R. W. Heath, "InFocus: A spatial coding technique to mitigate misfocus in near-field LoS beamforming," IEEE Trans. Wireless Commun., vol. 21, no. 4, pp. 2193�C2209, Apr. 2022.


*********************************************************************************************************************************
Enjoy the reproducible research!






